export default /* glsl */`
#ifdef USE_FOG

	fogDepth = -mvPosition.z;

#endif
`;
