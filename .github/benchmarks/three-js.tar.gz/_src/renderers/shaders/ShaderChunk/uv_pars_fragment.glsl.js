export default /* glsl */`
#ifdef USE_UV

	varying vec2 vUv;

#endif
`;
